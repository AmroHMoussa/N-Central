$mrkRestApiKey = ""
$orgID=""
$outputdirectory = "c:\CiscoMeraki"

$body=$null
$ResourceID = ('/organizations/' +$orgID + '/networks')
$Method = "GET" #('GET','POST','PUT','DELETE')

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$mrkRestApiHeader = @{"X-Cisco-Meraki-API-Key" = $mrkRestApiKey}
$orgURI = 'https://api.meraki.com/api/v1/organizations'
$webRequest = Invoke-WebRequest -uri $orgURI -Method GET -Headers ($mrkRestApiHeader)
$redirectedURL = $webRequest.BaseResponse.ResponseUri.AbsoluteUri
$orgBaseUri = $redirectedURL.Replace('/organizations','')
$uri = $orgBaseUri + $ResourceID
$request = Invoke-RestMethod -Method $Method -ContentType 'application/json' -Headers ($mrkRestApiHeader) -Uri $uri -Body ($body | ConvertTo-Json -Depth 10)

$request | FT -AutoSize
New-Item -ItemType Directory -Force -Path $outputdirectory
$fullpath = $outputdirectory + "\Networks.txt"
$request | out-file -FilePath $fullpath

