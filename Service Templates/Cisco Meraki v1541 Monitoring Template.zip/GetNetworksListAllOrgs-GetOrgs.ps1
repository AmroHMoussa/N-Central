$mrkRestApiKey = ""
$outputdirectory = "c:\CiscoMeraki"

$body=$null
$ResourceID = ('/organizations/')
$Method = "GET" #('GET','POST','PUT','DELETE')

[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

$mrkRestApiHeader = @{"X-Cisco-Meraki-API-Key" = $mrkRestApiKey}
$orgURI = 'https://api.meraki.com/api/v1/organizations'
$webRequest = Invoke-WebRequest -uri $orgURI -Method GET -Headers ($mrkRestApiHeader)
$redirectedURL = $webRequest.BaseResponse.ResponseUri.AbsoluteUri
$orgBaseUri = $redirectedURL.Replace('/organizations','')
$uri = $orgBaseUri + $ResourceID
$request = Invoke-RestMethod -Method $Method -ContentType 'application/json' -Headers ($mrkRestApiHeader) -Uri $uri -Body ($body | ConvertTo-Json -Depth 10)

$request | FT -AutoSize
New-Item -ItemType Directory -Force -Path $outputdirectory
$fullpath = $outputdirectory + "\Organizations.txt"
$request | Format-Table -AutoSize | out-file -FilePath $fullpath -Force



foreach ($orginfo in $request) {
    $ResourceID = ('/organizations/'+$orginfo.id+'/networks')
    $orgBaseUri = $redirectedURL.Replace('/organizations','')
    $uri = $orgBaseUri + $ResourceID
    $requestnetwork = Invoke-RestMethod -Method $Method -ContentType 'application/json' -Headers ($mrkRestApiHeader) -Uri $uri -Body ($body | ConvertTo-Json -Depth 10)

    if($requestnetwork.count -gt 0)
    {
        New-Item -ItemType Directory -Force -Path $outputdirectory
        $fullpath = $outputdirectory + "\Networks" + $orginfo.id +  ".txt"
        $requestnetwork | Format-Table  -AutoSize | out-file -FilePath $fullpath -Force
    }
    
}
